package com.tpo.lunchplanner;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class Menu extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu);
        Button nardiTermin = (Button) findViewById(R.id.button2);
        nardiTermin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openNewActivity(MakePlan.class);
            }
        });
        Button prikaziTermine = (Button) findViewById(R.id.button3);
        nardiTermin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openNewActivity(ShowPlans.class);
            }
        });
    }
    public void openNewActivity( Class novaStran){
        Intent intent = new Intent(this, novaStran);
        startActivity(intent);
    }
}
